﻿using LondonStockAPI.DTO;
using LondonStockAPI.Models;
using LondonStockAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LondonStockApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class Trades1Controller : ControllerBase
    {
        private readonly ITradeService _service;

        public Trades1Controller(ITradeService service)
        {
            _service = service;
        }
        [HttpPost]
        public async Task<IActionResult> PostTrade([FromBody] TradeDTO tradeDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(new ApiResponse<string>(false, "Invalid trade data"));

            var trade = await _service.AddTradeAsync(tradeDto);
            return Ok(new ApiResponse<Trade>(true, "Trade recorded successfully", trade));
        }
        //[HttpGet]
        //public async Task<IActionResult> GetTrades() =>
        //    Ok(await _service.GetTradesAsync());

        //[HttpPost]
        // public async Task<IActionResult> AddTrade([FromBody] TradeDTO dto)
        // {
        //     var trade = await _service.AddTradeAsync(dto);
        //    //return CreatedAtAction(nameof(GetTrades), new { id = trade.Id }, trade);
        //    return Ok(new ApiResponse<Trade>(true, "Trade recorded successfully", trade));
        //}

        /*[HttpPost]
        public async Task<IActionResult> PostTrade([FromBody] TradeDTO tradeDto)
        {
            var trade = new Trade
            {
                TickerSymbol = tradeDto.TickerSymbol.ToUpper(),
                Price = tradeDto.Price,
                Quantity = tradeDto.Quantity,
                BrokerId = tradeDto.BrokerId
            };

            _context.Trades.Add(trade);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Trade recorded successfully" });
        }
        */
        //[HttpGet("average/{symbol}")]
        //public async Task<IActionResult> GetAveragePrice(string symbol)
        //{
        //    var avg = await _service.GetAveragePriceAsync(symbol);
        //    return Ok(new { Symbol = symbol, AveragePrice = avg });
        //}
    }
}

