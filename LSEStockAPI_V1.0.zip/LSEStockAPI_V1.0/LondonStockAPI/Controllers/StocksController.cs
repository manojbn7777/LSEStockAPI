﻿using LondonStockAPI.Data;
using LondonStockAPI.Models;
using LondonStockAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Globalization;

namespace LondonStockAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StocksController : ControllerBase
    {
        // private readonly AppDBContext _context;
        private readonly ITradeService _tradeService;

        //public StocksController(AppDBContext context)
        //{
        //    _context = context;
        //}
        public StocksController(ITradeService tradeService)
        {
            _tradeService = tradeService;
        }

        [HttpGet("{ticker}")]
        public async Task<IActionResult> GetStockValue(string ticker)
        {
            var avgPrice = await _tradeService.GetStockValueAsync(ticker);

            if (avgPrice == null)
                return NotFound(new ApiResponse<string>(false, $"No trades found for ticker {ticker}"));

            return Ok(new
            {
                Ticker = ticker,
                AveragePrice = avgPrice, // numeric value
                AveragePriceFormatted = string.Format(new CultureInfo("en-GB"), "{0:C}", avgPrice), // £ formatted
                Currency = "GBP"
            });
        }

        [HttpGet]
        public async Task<IActionResult> GetAllStockValues()
        {
            var values = await _tradeService.GetAllStockValuesAsync();
            return Ok(new ApiResponse<IEnumerable<object>>(true, "All stock values retrieved", values));
        }

        [HttpPost("range")]
        public async Task<IActionResult> GetStockValuesForList([FromBody] List<string> tickers)
        {
            var values = await _tradeService.GetStockValuesForListAsync(tickers);
            return Ok(new ApiResponse<IEnumerable<object>>(true, "Stock values retrieved", values));
        }
    }
}

