﻿using LondonStockAPI.Data;
using LondonStockAPI.DTO;
using LondonStockAPI.Models;
using Microsoft.EntityFrameworkCore;
using System;

namespace LondonStockAPI.Services
{
    public class TradeService : ITradeService
    {
        //private readonly AppDBContext _context;

        //public TradeService(AppDBContext context)
        //{
        //    _context = context;
        //}

        //public async Task<List<Trade>> GetTradesAsync() =>
        //    await _context.Trades.ToListAsync();

        //public async Task<Trade> AddTradeAsync(TradeDTO dto)
        //{
        //    var trade = new Trade
        //    {
        //        TickerSymbol = dto.TickerSymbol,
        //        Quantity = dto.Quantity,
        //        Price = dto.Price,
        //        BrokerId= dto.BrokerId
        //        //Timestamp = DateTime.UtcNow
        //    };
        //    _context.Trades.Add(trade);
        //    await _context.SaveChangesAsync();
        //    return trade;

        //}

        //public async Task<decimal> GetAveragePriceAsync(string symbol)
        //{
        //    var trades = await _context.Trades
        //        .Where(t => t.TickerSymbol == symbol)
        //        .ToListAsync();

        //    if (!trades.Any()) return 0;

        //    return trades.Average(t => t.Price);
        //}

        private readonly AppDBContext _context;

        public TradeService(AppDBContext context)
        {
            _context = context;
        }

        public async Task<Trade> AddTradeAsync(TradeDTO tradeDto)
        {
            var trade = new Trade
            {
                TickerSymbol = tradeDto.TickerSymbol.ToUpper(),
                Price = tradeDto.Price,
                Quantity = tradeDto.Quantity,
                BrokerId = tradeDto.BrokerId
            };

            _context.Trades.Add(trade);
            await _context.SaveChangesAsync();
            return trade;
        }

        public async Task<decimal?> GetStockValueAsync(string ticker)
        {
            return await _context.Trades
                .Where(t => t.TickerSymbol == ticker.ToUpper())
                .Select(t => (decimal?)t.Price)
                .AverageAsync();
        }

        public async Task<IEnumerable<object>> GetAllStockValuesAsync()
        {
            return await _context.Trades
                .GroupBy(t => t.TickerSymbol)
                .Select(g => new { Ticker = g.Key, CurrentValue = g.Average(t => t.Price) })
                .ToListAsync();
        }

        public async Task<IEnumerable<object>> GetStockValuesForListAsync(List<string> tickers)
        {
            var upperTickers = tickers.Select(t => t.ToUpper()).ToList();

            return await _context.Trades
                .Where(t => upperTickers.Contains(t.TickerSymbol))
                .GroupBy(t => t.TickerSymbol)
                .Select(g => new { Ticker = g.Key, CurrentValue = g.Average(t => t.Price) })
                .ToListAsync();
        }
    }
}