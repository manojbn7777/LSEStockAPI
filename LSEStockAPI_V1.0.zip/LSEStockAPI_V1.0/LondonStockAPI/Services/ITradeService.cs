﻿using LondonStockAPI.DTO;
using LondonStockAPI.Models;

namespace LondonStockAPI.Services
{
    public interface ITradeService
    {
        //Task<List<Trade>> GetTradesAsync();
        //Task<Trade> AddTradeAsync(TradeDTO dto);
        //Task<decimal> GetAveragePriceAsync(string symbol);
        Task<Trade> AddTradeAsync(TradeDTO tradeDto);
        Task<decimal?> GetStockValueAsync(string ticker);
        Task<IEnumerable<object>> GetAllStockValuesAsync();
        Task<IEnumerable<object>> GetStockValuesForListAsync(List<string> tickers);

    }
}
