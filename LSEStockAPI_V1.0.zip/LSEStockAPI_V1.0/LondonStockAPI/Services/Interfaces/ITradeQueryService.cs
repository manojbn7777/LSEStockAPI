﻿using LondonStockAPI.DTO;
using LondonStockAPI.Models;

namespace LondonStockAPI.Services.Interfaces
{
    public interface ITradeQueryService
    {
        Task<decimal?> GetAveragePriceAsync(string symbol);
        Task<List<StocksAllDTO>> GetAllTradesAsync();
        Task<IEnumerable<object>> GetStockValuesForListAsync(List<string> tickers);
    }
}
