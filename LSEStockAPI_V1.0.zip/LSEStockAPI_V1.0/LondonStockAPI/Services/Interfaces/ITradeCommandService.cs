﻿using LondonStockAPI.DTO;
using LondonStockAPI.Models;

namespace LondonStockAPI.Services.Interfaces
{
    public interface ITradeCommandService
    {
        Task<Trade> AddTradeAsync(TradeDTO dto);
    }
}
