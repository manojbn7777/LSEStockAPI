﻿using LondonStockAPI.DTO;
using LondonStockAPI.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace LondonStockAPI.Data
{
    public class AppDBContext : IdentityDbContext<ApplicationUser>
    {
        public AppDBContext(DbContextOptions<AppDBContext> options) : base(options) { }


        public DbSet<Trade> Trades => Set<Trade>();
        public DbSet<Broker> Broker => Set<Broker>();





        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Trade>()
                .Property(t => t.Price)
                .HasPrecision(18, 4);

            modelBuilder.Entity<Trade>()
                .Property(t => t.Quantity)
                .HasPrecision(18, 4);
        }
    }
}
