﻿namespace LondonStockAPI.DTO
{
    public class StockValueDTO
    {
        public string Ticker { get; set; }
        public string AveragePrice { get; set; }
        public string Currency { get; set; }
    }
}
