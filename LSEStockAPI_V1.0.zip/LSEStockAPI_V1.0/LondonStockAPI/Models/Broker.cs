﻿using LondonStockAPI.Models;

public class Broker
{
    public int BrokerId { get; set; }
    public string Name { get; set; } = string.Empty;
}