﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LondonStockAPI.Migrations
{
    /// <inheritdoc />
    public partial class AddPricePrecision2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "BrokerId",
                table: "Trades",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "BrokerId",
                table: "Trades");
        }
    }
}
