﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LondonStockAPI.Migrations
{
    /// <inheritdoc />
    public partial class AddPricePrecision3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "StockSymbol",
                table: "Trades");

            migrationBuilder.RenameColumn(
                name: "Timestamp",
                table: "Trades",
                newName: "TradeTime");

            migrationBuilder.AlterColumn<decimal>(
                name: "Quantity",
                table: "Trades",
                type: "decimal(18,4)",
                precision: 18,
                scale: 4,
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<string>(
                name: "TickerSymbol",
                table: "Trades",
                type: "nvarchar(10)",
                maxLength: 10,
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "TickerSymbol",
                table: "Trades");

            migrationBuilder.RenameColumn(
                name: "TradeTime",
                table: "Trades",
                newName: "Timestamp");

            migrationBuilder.AlterColumn<int>(
                name: "Quantity",
                table: "Trades",
                type: "int",
                nullable: false,
                oldClrType: typeof(decimal),
                oldType: "decimal(18,4)",
                oldPrecision: 18,
                oldScale: 4);

            migrationBuilder.AddColumn<string>(
                name: "StockSymbol",
                table: "Trades",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }
    }
}
