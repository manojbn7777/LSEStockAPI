﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LondonStockAPI.Migrations
{
    /// <inheritdoc />
    public partial class AddPricePrecision4 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "BrokerId",
                table: "Trades",
                type: "int",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.CreateTable(
                name: "Broker",
                columns: table => new
                {
                    BrokerId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Broker", x => x.BrokerId);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Trades_BrokerId",
                table: "Trades",
                column: "BrokerId");

            migrationBuilder.AddForeignKey(
                name: "FK_Trades_Broker_BrokerId",
                table: "Trades",
                column: "BrokerId",
                principalTable: "Broker",
                principalColumn: "BrokerId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Trades_Broker_BrokerId",
                table: "Trades");

            migrationBuilder.DropTable(
                name: "Broker");

            migrationBuilder.DropIndex(
                name: "IX_Trades_BrokerId",
                table: "Trades");

            migrationBuilder.AlterColumn<string>(
                name: "BrokerId",
                table: "Trades",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");
        }
    }
}
