﻿using System;
using System.ComponentModel.DataAnnotations;

namespace LondonStockAPI.Attributes
{
    public class GreaterThanZeroAttribute : ValidationAttribute
    {
        public GreaterThanZeroAttribute()
        {
            ErrorMessage = "The {0} field must be greater than 0.";
        }

        public override bool IsValid(object value)
        {
            if (value == null) return false;

            if (decimal.TryParse(value.ToString(), out var number))
            {
                return number > 0;
            }

            return false;
        }
    }
}