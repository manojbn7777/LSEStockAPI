using FluentAssertions;
using LondonStockAPI.Controllers;
using LondonStockAPI.DTO;
using LondonStockAPI.Models;
using LondonStockAPI.Services.Interfaces;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using System.Reflection;

namespace LondonStockAPI.Tests.Controllers
{
    public class TradeServiceTests
    {
        private readonly Mock<ITradeCommandService> _mockCommandService;
        private readonly Mock<ITradeQueryService> _mockQueryService;
        private readonly Mock<ILogger<TradesController>> _mockLogger;
        private readonly TradesController _controller;

        public TradeServiceTests()
        {
            _mockCommandService = new Mock<ITradeCommandService>();
            _mockQueryService = new Mock<ITradeQueryService>();
            _mockLogger = new Mock<ILogger<TradesController>>();

            _controller = new TradesController(
                _mockCommandService.Object,
                _mockQueryService.Object,
                _mockLogger.Object
            );
        }

        // API Versioning Test
        [Fact]
        public void TradesController_ShouldHaveApiVersionAttribute()
        {
            // Act
            var attr = typeof(TradesController).GetCustomAttribute<ApiVersionAttribute>();

            // Assert
            attr.Should().NotBeNull("TradesController should have an ApiVersion attribute");
            attr.Versions.Should().ContainSingle(v => v.MajorVersion == 1 && v.MinorVersion == 0,
                "TradesController should be version 1.0");
        }

        // CORS Policy Test
        [Fact]
        public void TradesController_ShouldHaveEnableCorsAttribute()
        {
            // Act
            var attr = typeof(TradesController).GetCustomAttribute<EnableCorsAttribute>();

            // Assert
            attr.Should().NotBeNull("TradesController should have an EnableCors attribute");
            attr.PolicyName.Should().Be("LimitedCORS", "TradesController should use the LimitedCORS policy");
        }

        [Fact]
        public async Task AddTrade_ShouldReturnCreatedAtAction_WhenTradeIsAdded()
        {
            // Arrange
            var tradeDto = new TradeDTO { TickerSymbol = "VMW", Price = 150, Quantity = 10, BrokerId = 1 };
            var trade = new Trade { Id = 1, TickerSymbol = "VMW", Price = 150, Quantity = 10, BrokerId = 1 };

            _mockCommandService.Setup(s => s.AddTradeAsync(tradeDto))
                .ReturnsAsync(trade);

            // Act
            var result = await _controller.AddTrade(tradeDto);

            // Assert
            var createdResult = result.Should().BeOfType<CreatedAtActionResult>().Subject;
            createdResult.ActionName.Should().Be(nameof(TradesController.GetAllTrades));

            var apiResponse = createdResult.Value.Should().BeOfType<ApiResponse<Trade>>().Subject;
            apiResponse.Success.Should().BeTrue();
            apiResponse.Message.Should().Be("Trade created successfully");
            apiResponse.Data.Should().BeEquivalentTo(trade);
        }

        [Fact]
        public async Task AddTrade_ShouldReturnBadRequest_WhenInvalidOperationExceptionThrown()
        {
            // Arrange
            var tradeDto = new TradeDTO { TickerSymbol = "VMW", Price = 150, Quantity = 10, BrokerId = 1 };

            _mockCommandService.Setup(s => s.AddTradeAsync(tradeDto))
                .ThrowsAsync(new InvalidOperationException("Invalid trade"));

            // Act
            var result = await _controller.AddTrade(tradeDto);

            // Assert
            var badRequest = result.Should().BeOfType<BadRequestObjectResult>().Subject;
            var apiResponse = badRequest.Value.Should().BeOfType<ApiResponse<string>>().Subject;
            apiResponse.Success.Should().BeFalse();
            apiResponse.Message.Should().Be("Invalid trade");
            apiResponse.Data.Should().BeNull();
        }

        [Fact]
        public async Task GetAllTrades_ShouldReturnOk_WithStockValues()
        {
            // Arrange
            var stockValues = new List<StocksAllDTO>
            {
                new StocksAllDTO { TickerSymbol = "VMW", Price = 150.25M, Quantity = 100M, BrokerId = 1 }
            };

            _mockQueryService.Setup(s => s.GetAllTradesAsync())
                .ReturnsAsync(stockValues);

            // Act
            var result = await _controller.GetAllTrades();

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = okResult.Value.Should().BeOfType<ApiResponse<object>>().Subject;
            response.Success.Should().BeTrue();
            response.Message.Should().Be("Stock values retrieved");
            response.Data.Should().BeEquivalentTo(stockValues);
        }

        [Fact]
        public async Task GetAveragePrice_ShouldReturnNotFound_WhenNoTrades()
        {
            // Arrange
            _mockQueryService.Setup(s => s.GetAveragePriceAsync("VMW"))
                .ReturnsAsync((decimal?)0);

            // Act
            var result = await _controller.GetAveragePrice("VMW");

            // Assert
            var notFound = result.Should().BeOfType<NotFoundObjectResult>().Subject;
            var apiResponse = notFound.Value.Should().BeOfType<ApiResponse<string>>().Subject;
            apiResponse.Success.Should().BeFalse();
            apiResponse.Message.Should().Be("No trades found for ticker VMW");
            apiResponse.Data.Should().BeNull();
        }

        [Fact]
        public async Task GetAveragePrice_ShouldReturnOk_WhenTradesExist()
        {
            // Arrange
            _mockQueryService.Setup(s => s.GetAveragePriceAsync("VMW"))
                .ReturnsAsync(150.25m);

            // Act
            var result = await _controller.GetAveragePrice("VMW");

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var apiResponse = okResult.Value.Should().BeOfType<ApiResponse<object>>().Subject;
            apiResponse.Success.Should().BeTrue();
            apiResponse.Message.Should().Be("Stock value retrieved");

            var data = apiResponse.Data.Should().BeAssignableTo<object>().Subject;
            data.Should().NotBeNull();
        }

        [Fact]
        public async Task GetStockValuesForList_ShouldReturnOk_WithValues()
        {
            // Arrange
            var tickers = new List<string> { "VMW", "TES" };
            var values = new List<object>
            {
                new { Ticker = "VMW", AveragePrice = "�150.25", Currency = "GBP" },
                new { Ticker = "TES", AveragePrice = "�100.00", Currency = "GBP" }
            };

            _mockQueryService.Setup(s => s.GetStockValuesForListAsync(tickers))
                .ReturnsAsync(values);

            // Act
            var result = await _controller.GetStockValuesForList(tickers);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var apiResponse = okResult.Value.Should().BeOfType<ApiResponse<IEnumerable<object>>>().Subject;
            apiResponse.Success.Should().BeTrue();
            apiResponse.Message.Should().Be("Stock values retrieved");
            apiResponse.Data.Should().BeEquivalentTo(values);
        }

        [Fact]
        public void TradesController_ShouldHaveRateLimitingAttribute()
        {
            var attr = typeof(TradesController).GetCustomAttribute<EnableRateLimitingAttribute>();
            attr.Should().NotBeNull();
            attr.PolicyName.Should().Be("TradesPolicy");
        }
    }
}