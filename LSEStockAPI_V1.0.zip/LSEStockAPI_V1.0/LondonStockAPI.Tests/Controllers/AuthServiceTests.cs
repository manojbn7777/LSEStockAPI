﻿using FluentAssertions;
using LondonStockAPI.Controllers;
using LondonStockAPI.DTO;
using LondonStockAPI.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Moq;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Xunit;

namespace LondonStockAPI.Tests.Controllers
{
    public class AuthControllerTests
    {
        private readonly Mock<UserManager<ApplicationUser>> _mockUserManager;
        private readonly Mock<IConfiguration> _mockConfig;
        private readonly AuthController _controller;

        public AuthControllerTests()
        {
            var store = new Mock<IUserStore<ApplicationUser>>();
            _mockUserManager = new Mock<UserManager<ApplicationUser>>(
                store.Object, null, null, null, null, null, null, null, null
            );

            _mockConfig = new Mock<IConfiguration>();

            // Setup JWT config values
            _mockConfig.Setup(c => c["Jwt:Key"]).Returns("ThisIsASecretKeyForTesting123!");
            _mockConfig.Setup(c => c["Jwt:Issuer"]).Returns("TestIssuer");
            _mockConfig.Setup(c => c["Jwt:Audience"]).Returns("TestAudience");
            _mockConfig.Setup(c => c["Jwt:ExpireMinutes"]).Returns("60");

            _controller = new AuthController(_mockUserManager.Object, _mockConfig.Object);
        }

        [Fact]
        public async Task Login_ShouldReturnToken_WhenCredentialsAreValid()
        {
            // Arrange
            var user = new ApplicationUser { UserName = "testuser" };
            var roles = new List<string> { "Admin" };

            _mockUserManager.Setup(m => m.FindByNameAsync("testuser"))
                .ReturnsAsync(user);
            _mockUserManager.Setup(m => m.CheckPasswordAsync(user, "password"))
                .ReturnsAsync(true);
            _mockUserManager.Setup(m => m.GetRolesAsync(user))
                .ReturnsAsync(roles);

            var loginDto = new LoginDTO { Username = "testuser", Password = "password" };

            // Act
            var result = await _controller.Login(loginDto);

            // Assert
            var okResult = result.Should().BeOfType<OkObjectResult>().Subject;
            var response = okResult.Value.Should().BeAssignableTo<object>().Subject;

            response.Should().NotBeNull();
            var tokenProperty = response.GetType().GetProperty("token");
            tokenProperty.Should().NotBeNull();
            var tokenValue = tokenProperty.GetValue(response)?.ToString();
            tokenValue.Should().NotBeNullOrEmpty();

            // Validate token format
            var handler = new JwtSecurityTokenHandler();
            handler.CanReadToken(tokenValue).Should().BeTrue();
        }

        [Fact]
        public async Task Login_ShouldReturnUnauthorized_WhenPasswordIsInvalid()
        {
            // Arrange
            var user = new ApplicationUser { UserName = "testuser" };

            _mockUserManager.Setup(m => m.FindByNameAsync("testuser"))
                .ReturnsAsync(user);
            _mockUserManager.Setup(m => m.CheckPasswordAsync(user, "wrongpassword"))
                .ReturnsAsync(false);

            var loginDto = new LoginDTO { Username = "testuser", Password = "wrongpassword" };

            // Act
            var result = await _controller.Login(loginDto);

            // Assert
            result.Should().BeOfType<UnauthorizedResult>();
        }

        [Fact]
        public async Task Login_ShouldReturnUnauthorized_WhenUserNotFound()
        {
            // Arrange
            _mockUserManager.Setup(m => m.FindByNameAsync("unknown"))
                .ReturnsAsync((ApplicationUser)null);

            var loginDto = new LoginDTO { Username = "unknown", Password = "password" };

            // Act
            var result = await _controller.Login(loginDto);

            // Assert
            result.Should().BeOfType<UnauthorizedResult>();
        }
    }
}